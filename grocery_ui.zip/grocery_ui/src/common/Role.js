const Role={
  ADMIN: "ADMIN",
  GENERAL: "GENERAL"
}