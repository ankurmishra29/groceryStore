// all category detail
const productCategory = [
  {
    id: 1,
    label: "Fruits",
    value: "fruits",
  },
  {
    id: 2,
    label: "Vegetable",
    value: "vegetable",
  },
  {
    id: 3,
    label: "Oil",
    value: "oil",
  },
  {
    id: 4,
    label: "Masala",
    value: "masala",
  },
  {
    id: 5,
    label: "Foodgrains",
    value: "foodgrains",
  },
  {
    id: 6,
    label: "Dairy",
    value: "dairy",
  },
  {
    id: 7,
    label: "Snacks",
    value: "snacks",
  },
  {
    id: 8,
    label: "ColdDrink",
    value: "colddrink",
  },
];

export default productCategory;
